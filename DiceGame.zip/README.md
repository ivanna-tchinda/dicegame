# dicegame
 This is a dice game that I made for a course at Studi School
